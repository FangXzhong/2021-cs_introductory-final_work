# -*- coding: utf-8 -*-
"""
Created on Mon Apr  6 22:24:22 2020
@author: Justin
"""
'''
测试ChromeDriver
会弹出一个Chrome的窗口
'''

from selenium import webdriver

browser = webdriver.Chrome()

