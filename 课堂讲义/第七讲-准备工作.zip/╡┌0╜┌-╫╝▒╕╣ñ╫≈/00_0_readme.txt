﻿安装软件
1. Chrome
2. ChromeDriver
2.1 检查Chrome版本：菜单->帮助->关于……
2.2 下载对应版本的ChromeDriver
    网址：http://chromedriver.storage.googleapis.com/index.html
2.3 将chromedriver.exe复制到Python的Scripts目录（这里为Anaconda的安装目录下）
    路径：C:\ProgramData\Anaconda3\Scripts
    复制到这里的目的是免于配置环境变量，也可以不复制，自行配置环境变量
2.4 在命令行运行chromedriver。显示信息“Starting ChromeDriver ...”

(*)第三方库：
selenium
pyquery


