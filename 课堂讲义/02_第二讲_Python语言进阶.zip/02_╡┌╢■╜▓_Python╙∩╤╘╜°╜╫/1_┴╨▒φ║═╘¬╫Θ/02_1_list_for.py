﻿"""
Date: 2021.3.9
Author: Justin

要点说明：
用for循环输出列表中所有元素
"""

name_list = ['刘备', '关羽', '刘备', '张飞', '关羽', '刘备' ]

# 将列表作为一个整体输出，带有方括号和逗号
print(name_list)  

# 遍历列表中的每个元素
for name in name_list: 
    print(name)

