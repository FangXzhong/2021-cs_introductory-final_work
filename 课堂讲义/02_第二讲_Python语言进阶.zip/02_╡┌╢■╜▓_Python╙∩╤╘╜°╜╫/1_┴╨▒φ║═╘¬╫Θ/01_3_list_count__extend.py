"""
Date: 2020.3.7
Author: Justin

要点说明：
list.count(x)函数返回列表中x元素的数量
"""

name_list = ['刘备', '关羽', '刘备', '张飞', '关羽', '刘备' ]

print(name_list.count('刘备'))
print(name_list.count('关羽'))
print(name_list.count('张飞'))
