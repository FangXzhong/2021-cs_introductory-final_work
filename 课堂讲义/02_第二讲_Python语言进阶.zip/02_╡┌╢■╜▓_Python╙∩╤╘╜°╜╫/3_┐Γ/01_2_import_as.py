"""
Date: 2021.3.10
Author: Justin

要点说明：
加载内置库，并取新名字
"""

import time as t   
# 后续使用中，t.sleep(n)代表time.sleep(n)

print('真相')
t.sleep(1)
print('只有')
t.sleep(2)
print('一个')