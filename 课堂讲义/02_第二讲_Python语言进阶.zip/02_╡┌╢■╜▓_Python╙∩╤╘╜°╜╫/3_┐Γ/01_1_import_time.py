"""
Date: 2021.3.10
Author: Justin

要点说明：
加载内置库，调用库中的方法
"""

import time  # 加载time库，该库提供时间相关的功能

print('真相')

time.sleep(1)  # 调用time库中的sleep方法，暂停指定的秒数

print('只有')

time.sleep(2)

print('一个')