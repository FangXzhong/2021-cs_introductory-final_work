"""
Date: 2021.2.9
Author: Justin

要点说明：
1、使用input()函数输入信息，括号中可以写提示信息
2、输入时，按回车结束
"""

name = input('请输入姓名：')

print(name + '，你好！\n欢迎来到计算机的世界！')

