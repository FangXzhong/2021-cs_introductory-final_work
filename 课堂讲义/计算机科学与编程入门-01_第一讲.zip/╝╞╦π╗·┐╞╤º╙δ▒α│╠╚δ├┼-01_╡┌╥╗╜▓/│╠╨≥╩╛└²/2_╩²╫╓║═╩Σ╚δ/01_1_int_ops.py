"""
Date: 2020.10.13
Author: Justin

要点说明：
整数的四则运算
"""

a = 35    
b = 5  

s = a + b
print(s)

s = a - b
print(s)

s = a * b
print(s)

s = a / b   # 除法
print(s)
# 打印结果是7.0而不是7
# 无论是否整除，除法结果都是浮点数格式（可以先理解成“小数”，虽然不正确）


