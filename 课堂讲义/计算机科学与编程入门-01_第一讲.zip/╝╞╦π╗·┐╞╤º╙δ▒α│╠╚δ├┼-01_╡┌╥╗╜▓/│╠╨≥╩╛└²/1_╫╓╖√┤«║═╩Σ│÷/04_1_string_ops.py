"""
Date: 2021.2.9
Author: Justin

要点说明：
字符串的“运算”操作
+ 加号代表拼接
* 乘号代表复制
"""

name1 = '刘备'
name2 = '诸葛亮'

print('这个故事的主角是' + name1 + '和' + name2 + '。')

print(name1*10)

print('-'*20)  # 将短划线复制若干次，可以方便的生成分隔线